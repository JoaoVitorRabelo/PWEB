module.exports = function (app) {
    app.get('/informacao/professores', function (req, res) {
        const sql = require('mssql/msnodesqlv8');
        const sqlConfig = {
            user: 'LOGON',
            password: 'SENHA',
            database: 'site_fatec',
            server: 'NOME_DO_SERVIDOR',
        }

        async function getProfessores() {
            try {
                const pool = await sql.connect(sqlConfig);

                const results = await pool.request().query('SELECT * from PROFESSORES')

                res.render('informacao/professores', { profs: results.recordset });

            } catch (err) {
                console.log(err)
            }
        }
        const professores = getProfessores();
    });
}